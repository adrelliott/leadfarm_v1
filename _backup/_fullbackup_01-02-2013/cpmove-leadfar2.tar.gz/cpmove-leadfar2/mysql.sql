-- cPanel mysql backup
GRANT USAGE ON *.* TO 'leadfar2'@'localhost' IDENTIFIED BY PASSWORD '*DC8E2B1AC58C4FFAF9F61C16E83C3B4466BEC409';
GRANT ALL PRIVILEGES ON `leadfar2\_22222`.* TO 'leadfar2'@'localhost';
GRANT ALL PRIVILEGES ON `leadfar2\_22222\_1`.* TO 'leadfar2'@'localhost';
GRANT ALL PRIVILEGES ON `leadfar2\_%`.* TO 'leadfar2'@'localhost';
GRANT USAGE ON *.* TO 'leadfar2_admin'@'localhost' IDENTIFIED BY PASSWORD '*514F0E8773A56E489E7A0131B122AA124C3B164E';
GRANT ALL PRIVILEGES ON `leadfar2\_22222\_1`.* TO 'leadfar2_admin'@'localhost';
GRANT ALL PRIVILEGES ON `leadfar2\_22222`.* TO 'leadfar2_admin'@'localhost';
